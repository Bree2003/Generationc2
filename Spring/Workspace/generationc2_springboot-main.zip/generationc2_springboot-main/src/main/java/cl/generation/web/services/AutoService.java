package cl.generation.web.services;

import cl.generation.web.models.Auto;

public interface AutoService {
	public Auto guardarAuto(Auto auto);
}
