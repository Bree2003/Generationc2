package cl.generation.web.services;

import cl.generation.web.models.Rol;

public interface RolService {
	
	public Rol obtenerRol(Long id);

}
