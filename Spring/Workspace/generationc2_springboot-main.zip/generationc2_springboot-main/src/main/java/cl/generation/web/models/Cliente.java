package cl.generation.web.models;

import lombok.Getter;

@Getter
public class Cliente {
	
	private String nombre;
	private String apellido;
}
